
// Countdown reset every 2 days
function updateCountdown() {
  const now = new Date();
  const start = new Date(Math.floor(now.getTime() / (2 * 24 * 60 * 60 * 1000)) * (2 * 24 * 60 * 60 * 1000));
  const end = new Date(start.getTime() + 2 * 24 * 60 * 60 * 1000);
  const distance = end - now;

  const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((distance % (1000 * 60)) / 1000);

  document.getElementById("countdown").innerText = 
    "Temps restant : " + hours + "h " + minutes + "m " + seconds + "s";
}

setInterval(updateCountdown, 1000);
updateCountdown();
